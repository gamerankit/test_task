<?php

get_header(); ?>

	<body class="side-panel-dark has-loading-screen color-theme-blue">

    <!--PAGE-->

	<div id="page">
		<div class="cd-background-wrapper">
			<figure class="cd-floating-background">
				<div class="base-layer" data-background-color="#166bbf"></div>
				<!--end layer-->
				<div class="layer animate pointer-events-none" data-background-image="assets/img/dots.png" data-layer-depth="550"></div>
				<!--end layer-->
				<div class="layer animate" data-layer-depth="300">
					<div id="content">
						<div class="content-wrapper">
							<div class="container">
                                <div class="brand">
                                    <a href="#">
                                        <img src="assets/img/logo.png" alt="">
                                    </a>
                                </div>
                                <!--end brand-->
								<div class="heading">
                                    <div class="count-down" data-countdown-year="2018" data-countdown-month="6" data-countdown-day="21"></div>
									<h1 id="heading" class="large">We're Coming!</h1>
                                    <p>Fresh design and content is preparing right now.<br>Don't forget to subscribe to stay tuned!</p>
								</div>
								<!--end heading-->
								<a href="#" class="btn btn-default" data-toggle="modal" data-target="#modal-subscribe">Notify Me</a>
								<a href="#" class="btn btn-border open-side-panel">More Information</a>
							</div>
							<!--end container-->
						</div>
						<!--end content-wrapper-->
					</div>
					<!--end content-->
				</div>
				<!--end layer-->
			</figure>
			<!--end cd-floating-background-->
		</div>
		<!--end cd-background-wrapper-->
	</div>
	<!--end page-->

    <!--SIDE PANEL-->

    <div class="side-panel">
        <div class="nav-btn open-side-panel">
            <i></i>
            <i></i>
            <i></i>
        </div>
        <div class="wrapper">
            <div class="container-fluid">
                <section>
                    <h2>Welcome To Innovative Template</h2>
                    <p>
                        Aenean sed mi leo. Donec mollis ut sem sed scelerisque. Sed at lorem sem. Vestibulum ornare hendrerit augue,
                        suscipit finibus dui imperdiet ut. Quisque placerat nulla sed enim mattis aliquet. Phasellus vel nulla neque.
                        Maecenas faucibus lectus at nunc ultricies finibus.
                    </p>
                    <div class="gallery">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-1.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-1.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-2.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-2.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-3.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-3.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-4.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-4.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <h6>waiting does not ends</h6>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                        </div>
                    </div>
                </section>

                <section>
                    <h2>Our Skills</h2>
                    <div class="skill">
                        <h4>Webdesign</h4>
                        <aside>80%</aside>
                        <figure class="bar">
                            <div class="bar-active width-80"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                    <div class="skill">
                        <h4>Photography</h4>
                        <aside>100%</aside>
                        <figure class="bar">
                            <div class="bar-active width-100"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                    <div class="skill">
                        <h4>Marketing</h4>
                        <aside>60%</aside>
                        <figure class="bar">
                            <div class="bar-active width-60"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                </section>
                <section>
                    <h2>Contact Us</h2>
                    <section>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <h3>Address</h3>
                                <address>
                                    4758 Nancy Street
                                    <br>
                                    +1 919-571-2528
                                    <br>
                                    <a href="#">hello@example.com</a>
                                </address>
                            </div>
                            <!--end col-sm-6-->
                            <div class="col-md-6 col-sm-6">
                                <h3>Social</h3>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-facebook"></i>Facebook
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-twitter"></i>Twitter
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-youtube"></i>Youtube
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-pinterest"></i>Pinterest
                                    </a>
                                </figure>
                            </div>
                            <!--end col-sm-6-->
                        </div>
                    </section>
                    <section>
                        <h3>Map</h3>
                        <div class="map" id="map-contact"></div>
                    </section>
                    <section>
                        <h3>Contact Form</h3>
                        <form id="form-contact" method="post" class="form clearfix inputs-underline">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="form-contact-name" name="name" placeholder="Your Name" required>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-6 col-sm-6 -->
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="form-contact-email" name="email" placeholder="Your Email" required>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-6 col-sm-6 -->
                            </div>
                            <!--end row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea class="form-control" id="form-contact-message" rows="8" name="message" placeholder="Your Message" required></textarea>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-12 -->
                            </div>
                            <!--end row -->
                            <div class="form-group clearfix">
                                <button type="submit" class="btn pull-right btn-primary" id="form-contact-submit">Send a Message</button>
                            </div>
                            <!--end form-group -->
                            <div class="form-contact-status"></div>
                        </form>
                        <!--end form-contact -->
                    </section>
                </section>
                <p class="copyright">(C) 2017 ThemeStarz, All Rights Reserved</p>
            </div>
            <!--container-fluid-->
        </div>
    </div>
    <!--end side-panel-->

    <!--SUBSCRIBE MODAL-->

	<div class="modal fade" id="modal-subscribe" tabindex="-1" role="dialog" aria-labelledby="modal-subscribe-label">
		<div class="modal-dialog" role="document">
			<div class="modal-content" data-background-image="assets/img/pattern.png">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h2 class="modal-title" id="modal-subscribe-label">Stay Tuned</h2>
				</div>
                <!--end modal-header-->
				<div class="modal-body">
					<p>
						Be the first to know fresh news, updates and new releases! Just add your e-mail address and well
						let you know.
					</p>
				</div>
                <!--end modal-body-->
				<div class="modal-footer">
					<form class="form">
						<div class="form-group">
							<label for="subscribe-email">Email address</label>
							<input type="email" class="form-control" name="email" id="subscribe-email" placeholder="Email Address" required>
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
					</form>
				</div>
                <!--modal-footer-->
			</div>
            <!--modal-content-->
		</div>
        <!--modal-dialog-->
	</div>
	<!--end modal-->

	<script src="assets/js/jquery-2.1.1.js"></script>
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js"></script>
    <script src="assets/js/pace.min.js"></script>
    <script src="assets/js/jquery.plugin.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
	<script src="assets/js/parallax-hero.js"></script>
	<script src="assets/js/modernizr.js"></script>
	<script src="assets/js/vegas.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/shine.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<script type="text/javascript">

        var shine = new Shine(document.getElementById('heading'));

        window.addEventListener('mousemove', function(event) {
            shine.light.position.x = event.clientX;
            shine.light.position.y = event.clientY;
            shine.draw();
        }, false);

        var latitude = 34.038405;
        var longitude = -117.946944;
        var markerImage = "assets/img/map-marker-w.png";
        var mapTheme = "dark";
        var mapElement = "map-contact";
        google.maps.event.addDomListener(window, 'load', simpleMap(latitude, longitude, markerImage, mapTheme, mapElement));

	</script>

</body>

    <<?php get_footer(); ?>>
    <?php get_sidebar(); ?>
    