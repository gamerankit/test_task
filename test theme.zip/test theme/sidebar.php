<!--SIDE PANEL-->
<body>
    <div class="side-panel">
        <div class="nav-btn open-side-panel">
            <i></i>
            <i></i>
            <i></i>
        </div>
        <div class="wrapper">
            <div class="container-fluid">
                <section>
                    <h2>Welcome To Innovative Template</h2>
                    <p>
                        Aenean sed mi leo. Donec mollis ut sem sed scelerisque. Sed at lorem sem. Vestibulum ornare hendrerit augue,
                        suscipit finibus dui imperdiet ut. Quisque placerat nulla sed enim mattis aliquet. Phasellus vel nulla neque.
                        Maecenas faucibus lectus at nunc ultricies finibus.
                    </p>
                    <div class="gallery">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-1.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-1.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-2.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-2.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-3.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-3.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                            <div class="col-md-6 col-sm-6">
                                <div class="image">
                                    <a href="assets/img/img-4.jpg" class="image-popup">
                                        <div class="bg-transfer">
                                            <img src="assets/img/img-4.jpg" alt="">
                                        </div>
                                        <!--end bg-transfer-->
                                    </a>
                                    <h4>Waiting Here</h4>
                                    <p>Donec mollis ut sem sed scelerisque. Sed at lorem sem.</p>
                                </div>
                                <!--end image-->
                            </div>
                            <!--end col-md-6-->
                        </div>
                    </div>
                </section>

                <section>
                    <h2>Our Skills</h2>
                    <div class="skill">
                        <h4>Webdesign</h4>
                        <aside>80%</aside>
                        <figure class="bar">
                            <div class="bar-active width-80"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                    <div class="skill">
                        <h4>Photography</h4>
                        <aside>100%</aside>
                        <figure class="bar">
                            <div class="bar-active width-100"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                    <div class="skill">
                        <h4>Marketing</h4>
                        <aside>60%</aside>
                        <figure class="bar">
                            <div class="bar-active width-60"></div>
                            <div class="bar-background"></div>
                        </figure>
                    </div>
                    <!--end skill-->
                </section>
                <section>
                    <h2>Contact Us</h2>
                    <section>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <h3>Address</h3>
                                <address>
                                    4758 Nancy Street
                                    <br>
                                    +1 919-571-2528
                                    <br>
                                    <a href="#">hello@example.com</a>
                                </address>
                            </div>
                            <!--end col-sm-6-->
                            <div class="col-md-6 col-sm-6">
                                <h3>Social</h3>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-facebook"></i>Facebook
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-twitter"></i>Twitter
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-youtube"></i>Youtube
                                    </a>
                                </figure>
                                <figure>
                                    <a href="#" class="icon">
                                        <i class="fa fa-pinterest"></i>Pinterest
                                    </a>
                                </figure>
                            </div>
                            <!--end col-sm-6-->
                        </div>
                    </section>
                    <section>
                        <h3>Map</h3>
                        <div class="map" id="map-contact"></div>
                    </section>
                    <section>
                        <h3>Contact Form</h3>
                        <form id="form-contact" method="post" class="form clearfix inputs-underline">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="form-contact-name" name="name" placeholder="Your Name" required>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-6 col-sm-6 -->
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="form-contact-email" name="email" placeholder="Your Email" required>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-6 col-sm-6 -->
                            </div>
                            <!--end row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea class="form-control" id="form-contact-message" rows="8" name="message" placeholder="Your Message" required></textarea>
                                    </div>
                                    <!--end form-group -->
                                </div>
                                <!--end col-md-12 -->
                            </div>
                            <!--end row -->
                            <div class="form-group clearfix">
                                <button type="submit" class="btn pull-right btn-primary" id="form-contact-submit">Send a Message</button>
                            </div>
                            <!--end form-group -->
                            <div class="form-contact-status"></div>
                        </form>
                        <!--end form-contact -->
                    </section>
                </section>
                <p class="copyright">(C) 2017 ThemeStarz, All Rights Reserved</p>
            </div>
            <!--container-fluid-->
        </div>
    </div>
    <!--end side-panel-->
</body>
